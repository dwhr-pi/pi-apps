#!/bin/bash
#
# Description : MEAN Environment to developers
# Author      : Jose Cerrejon Gonzalez (ulysess@gmail_dot._com)
# Version     : 0.1
#
# HELP        · 
#			  
clear
