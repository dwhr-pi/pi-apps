---
name: App request
about: Suggest/submit an app to be added to Pi-Apps
title: ''
labels: App Request
assignees: ''

---

Can this app run on RPi? If so, please provide a link to a tutorial if applicable.

Is this app something many GUI users would find useful?

Is this app installable with `sudo apt install`?

If you've created a zip file for this app, upload it here.
