---
name: Suggestion
about: Have an idea for Pi-Apps and it's not a bug or app request?
title: ''
labels: suggestion
assignees: ''

---


