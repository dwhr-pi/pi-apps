---
name: Bug report
about: App failing to install? It's still around after uninstalling? Let us know!
title: ''
labels: ''
assignees: ''

---


